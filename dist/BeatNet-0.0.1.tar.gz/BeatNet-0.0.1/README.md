# BeatNet
This repository contains the source code and additional documentations of the project BeatNet: CRNN and Particle Filtering for Online Joint beat, Downbeat and Meter Tracking.

Note: All source codes and files will be shared in here soon! 
