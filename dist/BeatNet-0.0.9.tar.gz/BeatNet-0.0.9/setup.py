"""
Created 07-01-21 by Moji Heydari
"""


# Local imports
# None.

# Third party imports
# None.

# Python standard library imports
import setuptools
from setuptools import find_packages
import distutils.cmd


# Required packages
REQUIRED_PACKAGES = [
    'numpy==1.19.5',
    'Cython==0.29.21',
    'configipy',
    'librosa==0.8.0',
    'numba==0.48.0', # Manually specified here as librosa incorrectly states that it is compatible with the latest version of numba although 0.50.0 is not compatible. 
    'audipy',
    'scipy==1.6.0',
    'mido>=1.2.6',
    'pytest',
    #'pyaudio',
    #'pyfftw',
    'madmom',
]


class MakeReqsCommand(distutils.cmd.Command):
  """A custom command to export requirements to a requirements.txt file."""

  description = 'Export requirements to a requirements.txt file.'
  user_options = []

  def initialize_options(self):
    """Set default values for options."""
    pass

  def finalize_options(self):
    """Post-process options."""
    pass

  def run(self):
    """Run command."""
    with open('./requirements.txt', 'w') as f:
        for req in REQUIRED_PACKAGES:
            f.write(req)
            f.write('\n')


setuptools.setup(
    cmdclass={
        'make_reqs': MakeReqsCommand
    },

    # Package details
    name="BeatNet",
    version="0.0.9",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    # packages=find_packages(),
    include_package_data=True,
    install_requires=REQUIRED_PACKAGES,

    # Metadata to display on PyPI
    author="Moji Heydari",
    author_email="mj.hydri@gmail.com",
    description="A package for online and offline beat tracking using BeatNet",
    keywords="Music Beat and Downbeat Tracking",
    url="https://bitbucket.savagebeast.com/users/mheydari/repos/joint-beat-and-downbeat-tracking"


    # CLI - not developed yet
    #entry_points = {
    #    'console_scripts': ['beatnet=beatnet.cli:main']
    #}
)
